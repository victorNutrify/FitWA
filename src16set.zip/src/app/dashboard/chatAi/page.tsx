import MealLogger from "@/components/dashboard/meal-logger"

export default function IAChatPage() {
  return <MealLogger />
}