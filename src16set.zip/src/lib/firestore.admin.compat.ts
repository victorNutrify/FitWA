// src/lib/firestore.admin.compat.ts
import { adminDb } from "./firebase.admin";

// Cria uma referência a partir de segmentos alternando collection/doc
export function doc(db: any, ...pathSegments: string[]) {
  let ref: any = adminDb;
  for (let i = 0; i < pathSegments.length; i++) {
    if (i % 2 === 0) ref = ref.collection(pathSegments[i]);
    else ref = ref.doc(pathSegments[i]);
  }
  return ref;
}

export function collection(base: any, ...pathSegments: string[]) {
  // se veio um DocumentReference, começa dele
  let ref: any = base && typeof base.collection === "function" ? base : adminDb;

  for (const seg of pathSegments) {
    ref = ref.collection(seg);
  }

  return ref;
}

export async function setDoc(ref: any, data: any, opts?: { merge?: boolean }) {
  if (opts?.merge) return ref.set(data, { merge: true });
  return ref.set(data);
}

export async function getDoc(ref: any) {
  const snap = await ref.get();
  return {
    exists: snap.exists,
    data: () => (snap.exists ? snap.data() : undefined),
    ref,
    id: ref.id,
  };
}

export async function getDocs(q: any) {
  return await q.get();
}

export async function deleteDoc(ref: any) {
  return await ref.delete();
}

export async function runTransaction(db: any, fn: (tx: any) => Promise<any>) {
  return adminDb.runTransaction(fn);
}

// Exporta o db para manter a interface compatível
export const db = adminDb;
