"use client"

import React, { createContext, useContext, useState } from "react"

type ChatReply = {
  reply: string
  alimentos: any[]
  calorias: number | null
  proteina: number | null
  carboidrato: number | null
  gordura: number | null
  totalCalorias: number
  totalProteina: number
  totalCarboidrato: number
  totalGordura: number
}

type ChatContextType = {
  lastChatReply: ChatReply | null
  setLastChatReply: (reply: ChatReply | null) => void
  chatLoading: boolean
  setChatLoading: (loading: boolean) => void
}

const ChatContext = createContext<ChatContextType | undefined>(undefined)

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [lastChatReply, setLastChatReply] = useState<ChatReply | null>(null)
  const [chatLoading, setChatLoading] = useState(false)

  return (
    <ChatContext.Provider value={{ lastChatReply, setLastChatReply, chatLoading, setChatLoading }}>
      {children}
    </ChatContext.Provider>
  )
}

export function useChatContext() {
  const context = useContext(ChatContext)
  if (!context) {
    throw new Error("useChatContext deve ser usado dentro de <ChatProvider>")
  }
  return context
}